# Lecture 37–39 Practical Report

## Title

Deployment Environments, Containerization, and Docker

## Name

Sehaj Vohra

## SAP ID

590011624

## Course

Backend Development

## Program

B.Tech Computer Science and Engineering

## Semester

5

## Objective

To understand deployment environments and containerization, install and verify Docker, create equivalent Student API applications using FastAPI and Express, build separate Docker images for both applications, run the containers with port mapping, and verify their HTTP endpoints.

## Software Requirements

The practical was implemented and tested using:

- Windows operating system
- Docker Desktop with the WSL 2 backend
- Docker Engine and Docker CLI
- Python 3.12 base image for the FastAPI container
- FastAPI 0.115.6
- Uvicorn 0.34.0
- Node.js 22 Alpine base image for the Express container
- Express 4.21.2 compatible dependency range
- Web browser or HTTP client for endpoint verification
- Visual Studio Code or another code editor

## Problem Statement

Create the same small Student API using FastAPI and Express. Build an independent Docker image for each implementation, run both containers, and verify the following endpoints:

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Return the application name, framework, and running status |
| GET | `/health` | Return the health status |
| GET | `/students` | Return the list of students |

The two applications must be accessible through separate host ports so that both containers can run at the same time.

## Task Summary

| Task | Description | Implementation |
|---|---|---|
| Task 1 | Install and verify Docker | Docker Desktop was installed and verified using Docker CLI commands and the `hello-world` image. |
| Task 2 | Create and containerize the FastAPI Student API | Implemented the API, declared Python dependencies, created a Dockerfile and `.dockerignore`, and built the FastAPI image. |
| Task 3 | Create and containerize the Express Student API | Implemented the equivalent API, configured the Node.js package, created a Dockerfile and `.dockerignore`, and built the Express image. |
| Task 4 | Run and test both containers together | Ran the FastAPI and Express containers on separate ports and tested their endpoints. |
| Task 5 | Inspect container logs, images, and cleanup | Inspected Docker images and container logs, then stopped and removed the containers. |

## Task 1: Install and Verify Docker

### Task Given

Install Docker in the development environment and verify that the Docker command line tool and Docker engine can run containers.

### Implementation

Docker Desktop was installed on Windows using the WSL 2 backend. During installation, the required Windows features for WSL and Virtual Machine Platform had to be enabled, followed by a system restart and WSL setup.

Docker was then verified using the Docker version command and by running the `hello-world` image. The Docker images and container listing commands were also used to inspect the result.

The Docker engine was subsequently confirmed to be available before building the Student API images.

### Code Location

This task involved Docker installation and command line verification. It does not have an application source file in the `docker-student-api` project folder.

### Screenshot

No Docker installation screenshot was present in the supplied `docker-student-api` folder listing. Therefore, no screenshot link is included for this task.

### Result

Docker Desktop and the Docker engine were verified successfully. The `hello-world` container printed its success message, confirming that Docker could download and run an image.

## Task 2: Create and Containerize the FastAPI Student API

### Task Given

Create a Student API using FastAPI with the `/`, `/health`, and `/students` GET endpoints. Define the Python dependencies, write a Dockerfile, exclude unnecessary files from the build context, build a Docker image, and run the application in a container.

### Implementation

The FastAPI application was implemented in `main.py`. It defines the application title and a student list containing two records:

- Aarav, enrolled in Backend Development
- Diya, enrolled in Backend Development

The application provides three GET endpoints:

- `/` returns the application name, framework name, and running status.
- `/health` returns `{"status": "healthy"}`.
- `/students` returns the student records.

The dependencies were pinned in `requirements.txt` to FastAPI 0.115.6 and Uvicorn 0.34.0.

A Dockerfile was created using `python:3.12-slim` as the base image. It sets `/app` as the working directory, installs the listed dependencies, copies `main.py`, documents port 8000, and starts Uvicorn on `0.0.0.0:8000`.

The `.dockerignore` file excludes Python cache files, bytecode, the virtual environment, and the Git directory from the Docker build context.

The image was built with the tag `student-api-fastapi:1.0`. The container was run with host port 8000 mapped to container port 8000.

### Code Location

- [FastAPI application: main.py](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/main.py)
- [Python dependencies: requirements.txt](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/requirements.txt)
- [FastAPI Dockerfile](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/Dockerfile)
- [FastAPI .dockerignore](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/.dockerignore)
- [FastAPI application folder](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app)

### Screenshots

**FastAPI Docker image build**

![FastAPI image build](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/screenshots/fastapi-image-build.png)

**FastAPI container running**

![FastAPI container running](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/screenshots/fastapi-container-running.png)

**FastAPI endpoint tests**

![FastAPI endpoint tests](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/screenshots/fastapi-endpoint-tests.png)

**FastAPI container status**

![FastAPI container status](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/screenshots/fastapi-container-status.png)

### Result

The `student-api-fastapi:1.0` image was built successfully. The FastAPI container ran with port mapping `8000:8000`. The root, health, and students endpoints returned the expected application information, healthy status, and student list.

## Task 3: Create and Containerize the Express Student API

### Task Given

Create an equivalent Student API using Express. Configure the Node.js package, implement the required GET endpoints, create a Dockerfile and `.dockerignore`, build a separate Docker image, and run the application in a container.

### Implementation

The Express application was implemented in `server.js`. It uses the Express framework and defines the same two student records used by the FastAPI application.

The application provides the following GET endpoints:

- `/` returns the application name, framework name, and running status.
- `/health` returns `{"status": "healthy"}`.
- `/students` returns the student records.

The application reads its port from `process.env.PORT`, using port 3000 as the default, and listens on `0.0.0.0`.

The `package.json` file defines the application metadata, the `npm start` command, and the Express dependency. The project also contains `package-lock.json`, generated during dependency installation.

A Dockerfile was created using `node:22-alpine` as the base image. It sets `/app` as the working directory, copies the package files, installs production dependencies, copies `server.js`, documents port 3000, and starts the application using `npm start`.

The `.dockerignore` file excludes `node_modules`, npm debug logs, the Git directory, and `.env` files from the Docker build context.

The image was built with the tag `student-api-express:1.0`. The container was run with host port 3000 mapped to container port 3000.

### Code Location

- [Express application: server.js](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/server.js)
- [Node.js package configuration: package.json](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/package.json)
- [Dependency lock file: package-lock.json](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/package-lock.json)
- [Express Dockerfile](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/Dockerfile)
- [Express .dockerignore](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/.dockerignore)
- [Express application folder](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app)

### Screenshots

**Express Docker image build**

![Express image build](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/screenshots/express-image-build.png)

**Express container running**

![Express container running](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/screenshots/express-container-running.png)

**Express endpoint tests**

![Express endpoint tests](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/screenshots/express-endpoint-tests.png)

### Result

The `student-api-express:1.0` image was built successfully. The Express container ran with port mapping `3000:3000`. The root, health, and students endpoints returned the expected application information, healthy status, and student list.

## Task 4: Run and Test Both Containers Together

### Task Given

Run the FastAPI and Express containers at the same time using separate host ports. Verify that both implementations expose the required API contract and return equivalent student data.

### Implementation

The FastAPI container was made available through host port 8000, while the Express container was made available through host port 3000.

Both containers were confirmed as running through Docker container inspection. Requests were sent to the health and students endpoints of both applications. The responses confirmed that both implementations returned a healthy status and the same two student records.

### Code Location

- [FastAPI application](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app)
- [Express application](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app)
- [Complete Student API project folder](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39/docker-student-api)

### Screenshots

**Both containers running**

![Both containers running](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/screenshots/both-containers-running.png)

**FastAPI and Express API comparison**

![Both APIs comparison](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/screenshots/both-apis-comparison.png)

### Result

Both containers ran simultaneously on their separate ports. The tested endpoints returned successful responses, and both applications provided the same student data through the common API contract.

## Task 5: Inspect Container Logs, Images, and Cleanup

### Task Given

Inspect the built Docker images, review the logs generated by both containers, and stop and remove the containers after testing.

### Implementation

Docker image inspection confirmed the presence of the FastAPI image tagged `student-api-fastapi:1.0` and the Express image tagged `student-api-express:1.0`.

The logs for both containers were inspected to review application startup and request activity. After testing, both containers were stopped and removed. A final container listing was used to verify that the test containers had been removed. The Docker images were retained.

### Code Location

This task used Docker CLI commands and the two Dockerfiles listed in the previous tasks. It does not introduce an additional application source file.

- [FastAPI Dockerfile](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/fastapi-app/Dockerfile)
- [Express Dockerfile](https://github.com/sehajvohra/BackendDevelopment/blob/main/Theory/Unit4/Lecture37-39/docker-student-api/express-app/Dockerfile)

### Screenshots

**Container logs**

![Both container logs](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/screenshots/both-container-logs.png)

**Final Docker images**

![Final Docker images](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/screenshots/docker-images-final.png)

**Container cleanup**

![Docker container cleanup](https://raw.githubusercontent.com/sehajvohra/BackendDevelopment/main/Theory/Unit4/Lecture37-39/docker-student-api/screenshots/docker-container-cleanup.png)

### Result

The logs showed the applications starting and processing the tested requests. Both test containers were stopped and removed successfully. The final container listing was empty, while the two built application images remained available locally.

## Project Structure

The following structure reflects the supplied project tree. The generated `node_modules` dependency directory is present locally but is not reproduced in this summary because it is not application source code.

```text
docker-student-api/
├── express-app/
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── package-lock.json
│   ├── package.json
│   ├── server.js
│   └── screenshots/
│       ├── express-container-running.png
│       ├── express-endpoint-tests.png
│       └── express-image-build.png
├── fastapi-app/
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── main.py
│   ├── requirements.txt
│   └── screenshots/
│       ├── fastapi-container-running.png
│       ├── fastapi-container-status.png
│       ├── fastapi-endpoint-tests.png
│       └── fastapi-image-build.png
└── screenshots/
    ├── both-apis-comparison.png
    ├── both-container-logs.png
    ├── both-containers-running.png
    ├── docker-container-cleanup.png
    └── docker-images-final.png
```

## Concepts Used

- Deployment environments and application configuration
- Containerization and portable application execution
- Docker Desktop, Docker Engine, and Docker CLI
- Dockerfiles and base images
- Docker image creation and tagging
- Docker containers and container lifecycle
- Port mapping between host and container
- Docker build context and `.dockerignore`
- Python dependencies and Uvicorn
- Node.js package configuration and Express
- HTTP GET routes and JSON responses
- Binding application servers to `0.0.0.0`
- Container inspection and log analysis
- Testing equivalent API implementations
- Stopping and removing containers

## Overall Result

Two implementations of the Student API were created, one using FastAPI and the other using Express. Separate Docker images were built successfully for both applications. The containers were run on host ports 8000 and 3000, and the required endpoints were tested. Both APIs returned healthy status responses and equivalent student records. Container logs were inspected, and the test containers were stopped and removed after verification.

## Observations

1. Docker images package an application and its required runtime dependencies, while containers are runnable instances of those images.
2. The FastAPI and Express applications used different runtimes and frameworks but implemented the same three endpoint paths.
3. Mapping host port 8000 to container port 8000 and host port 3000 to container port 3000 allowed both APIs to run simultaneously.
4. Both applications listened on `0.0.0.0` inside their containers so that requests could reach them through Docker port mapping.
5. The `.dockerignore` files excluded development and unnecessary files from their respective Docker build contexts.
6. The health and students endpoint tests showed that both implementations returned equivalent API data.
7. Container logs provided information about application startup and incoming requests.
8. Removing a container did not require removing its Docker image. The application images remained available after container cleanup.

## Conclusion

This practical demonstrated the use of Docker for packaging and running backend applications in reproducible container environments. The Student API was implemented independently with FastAPI and Express, and each implementation was built into its own Docker image. Both containers were run on separate ports and their endpoints were verified successfully. The practical also demonstrated image inspection, log analysis, and container cleanup.

## Experiment Link

The supplied material confirms the project source location but does not provide a verified experiment specific GitHub Pages URL. The general course site is available at [Backend Development GitHub Pages](https://sehajvohra.github.io/BackendDevelopment/).

## Complete Experiment Source Code

[Open the complete Lecture 37–39 Docker Student API folder on GitHub](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39/docker-student-api)

[Open the Lecture 37–39 project directory](https://github.com/sehajvohra/BackendDevelopment/tree/main/Theory/Unit4/Lecture37-39)
